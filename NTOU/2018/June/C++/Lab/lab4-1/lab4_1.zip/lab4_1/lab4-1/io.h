#pragma once
#include<fstream>
#include<vector>

#include "Complex.h"

using namespace std;

void readFile(vector<Complex> &);