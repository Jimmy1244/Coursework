#include<vector>

#include "Complex.h"

using namespace std;

void vectorAdd(vector<Complex> &);
void sortVector(vector<Complex> &);